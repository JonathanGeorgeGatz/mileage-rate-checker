# EP30 — The Mileage Rate Checker — SPEC (written before any implementation; tie-breaks live HERE)

A Google Sheet with one menu (Mileage → Check mileage). It reads the company's own mileage log and its
own rate table, recomputes what every trip should have been reimbursed, compares that with what was
actually paid, and names who was underpaid and who was overpaid. It never sends, uploads or pays anything.

## Inputs (row 1 of each tab = headers; matched case-insensitively after trimming and collapsing spaces;
## any column order; extra columns ignored)

### Trips (required tab)
Required headers: `Date driven`, `Employee`, `From`, `To`, `Odometer start`, `Odometer end`, `Miles`,
`Purpose`, `Amount paid`. Optional: `Date submitted`, `Rate paid` (used only for the explanation note).
If any required header is missing, the Trips header row is unreadable: every non-blank data row is refused
with reason `Trips header row unreadable`, nothing is priced, and the banner goes up.

A data row whose required cells are all empty is skipped and not counted. Every other data row counts as
one row in.

### Settings (rate table; optional tab)
Headers: `From`, `To`, `Rate per mile`. Each data row is one date range (inclusive both ends) and a rate.
- If the Settings tab is missing entirely (or has no data rows), the default table is used and the report
  says so: 2026-01-01 → 2026-06-30 at $0.725; 2026-07-01 → 2026-12-31 at $0.76 (IRS business standard
  mileage rates: IR-2025-128 / Notice 2026-10; Announcement 2026-11, effective on or after July 1, 2026).
- If the tab exists but a header is missing: the rate table is unreadable.
- A data row with an unreadable date, a To before its From, or an unreadable rate is refused (Settings row
  number + reason) and makes the rate table unreadable.
- Two ranges that share any day make the rate table unreadable ("rate dates overlap").
- **When the rate table is unreadable, nothing is priced**: every trip that would otherwise be checked is
  set aside with reason `rate table unreadable — nothing priced`, and the banner goes up.

### Value formats
- Dates: `YYYY-MM-DD` or `M/D/YYYY` (1–2 digit month and day, 4-digit year). Must be a real calendar
  date. Anything else is unreadable.
- Odometer readings and Miles: a non-negative decimal with at most ONE decimal place, commas allowed as
  thousands separators (`48,213.4`). Stored as integer tenths of a mile.
- Rates: a decimal dollar amount with at most THREE decimal places, optional leading `$` (`0.725`,
  `$0.76`). Stored as integer tenths of a cent ("mills"). Must be > 0.
- Money (Amount paid): optional `$`, commas allowed, at most two decimals. Stored as integer cents.

## Per-row rules, in this order (the FIRST failing rule decides the reason)
1. `unreadable date driven` — Date driven unreadable.
2. `no employee` — Employee blank.
3. `no business purpose` — Purpose blank.
4. Miles:
   - If exactly one of Odometer start / Odometer end is filled → `odometer start and end must both be filled`.
   - If both are filled: either unreadable → `unreadable odometer`; end ≤ start → `odometer end is not after start`.
     Odometer miles = end − start.
   - If Miles is filled and unreadable or zero → `unreadable miles`.
   - If both odometer miles and Miles exist and differ → `miles typed as M don't match the odometer (O)`
     where M and O are written with one decimal (e.g. `miles typed as 24.0 don't match the odometer (18.4)`).
   - If neither exists → `no miles and no odometer`.
   - Trip miles = odometer miles when present, else Miles.
5. Amount paid: blank = $0.00 (not paid yet; allowed). Unreadable → `unreadable amount paid`.
6. Duplicate: two rows with the same Employee (case-insensitive), Date driven, From and To
   (case-insensitive, trimmed), odometer start, odometer end and Miles (as parsed values, blanks equal) are
   the same trip. The FIRST row in sheet order is kept; each later one is refused with
   `duplicate trip — the first row was kept`. (Only rows that passed rules 1–5 enter the duplicate check.)
7. Rate: the rate is the one whose range contains the DATE DRIVEN. Never the date submitted, never the date
   paid. No range contains it → set aside with `no rate in Settings covers <date>` (date as YYYY-MM-DD).
8. Otherwise the trip is checked.

### Odometer overlap (after rules 1–8, among checked trips that have odometer readings)
Per employee (case-insensitive), sort those trips by (date driven, odometer start, sheet row). Walk them
in order, keeping the last KEPT trip: if a trip's odometer start is less than the kept trip's odometer
end, the trip is moved from checked to refused with reason
`odometer overlaps row N — the same miles claimed twice` (N = the kept trip's sheet row). Otherwise it
becomes the kept trip. Trips without odometer readings are not part of this check.

## Money (integer arithmetic only)
- Owed for a trip = round half up of (miles in tenths × rate in mills) / 100, in cents.
  (miles × rate, rounded to the nearest cent per trip, half a cent rounds up.)
- Paid for a trip = Amount paid in cents. Difference = paid − owed (positive = overpaid).
- Per employee (checked trips only): trips, miles, owed, paid, difference. Employees listed in order of
  first appearance in the Trips tab (case-insensitive name; the first spelling is shown).
- Totals: owed, paid, overpaid = sum of positive employee differences, underpaid = sum of the absolute
  values of negative employee differences.
- Paid on rows that were NOT checked (refused or set aside, readable amounts only) is reported separately
  as "paid on rows not checked"; it is in no other total.
- Mismatched trips: every checked trip whose difference ≠ 0, listed in sheet order, with a note:
  if a Rate paid column exists and its value is readable and differs from the trip's rate →
  `paid at $X/mi; the rate for YYYY-MM-DD is $Y/mi` (rates written with three decimals, e.g. $0.725, $0.760);
  otherwise `paid $A; owed $B`.

## Self-audit — banner `DO NOT TRUST THESE MILEAGE TOTALS` with reasons (joined with " · ")
- `header row unreadable: Trips` / `header row unreadable: Settings`
- `rate table unreadable` (bad rate row or overlapping dates)
- `rows do not add up` — rows in ≠ checked + set aside + refused
- `money does not re-add` — owed summed by trip ≠ owed summed by employee, or the same for paid, or
  (paid − owed) ≠ overpaid − underpaid
- `more than 10% of rows refused` — refused / rows in > 0.10
Otherwise the banner reads `OK`.

## Out of scope (said in the README, never guessed)
Commuting rules, personal-vs-business judgment, fixed-and-variable-rate plans, other countries' rates,
taxes. The sheet pays every checked trip at the company's own rate table.

## Lists and order
- Refused rows are listed in sheet-row order; set-aside rows in sheet-row order; checked trips in sheet order.
- "Paid on rows not checked" = for every refused or set-aside row (Trips header readable), its Amount paid
  if readable (blank = $0.00); unreadable amounts add nothing.
